let encryptedFinal=")%(@$:-%2*&*^.26`6-";
  let encryptedMessage;
function ognp(){

var pas=document.getElementById("lname").value;
encryptor(pas);
if(encryptedFinal==encryptedMessage){
  alert("SUCCESS");
}else{
  alert("wrong FLAG");
}
}

var message="HELLO";
function encryptor(message){

  const messagearr = message.split("");
  let encryptedMessageArr=[];
  for(i=0;i<messagearr.length;i++){

    let letter;
    switch(messagearr[i]){
      case "a":
      letter=",";
      break;
      case "b":
      letter=".";
      break;
      case "c":
      letter="/";
      break;
      case "d":
      letter=":";
      break;
      case "e":
      letter="]";
      break;
      case "f":
      letter="[";
      break;
      case "g":
      letter="+";
      break;
      case "h":
      letter="-";
      break;
      case "i":
      letter="_";
      break;
      case "j":
      letter=")";
      break;
      case "k":
      letter="(";
      break;
      case "l":
      letter="*";
      break;
      case "m":
      letter="&";
      break;
      case "n":
      letter="^";
      break;
      case "o":
      letter="%";
      break;
      case "p":
      letter="$";
      break;
      case "q":
      letter="#";
      break;
      case "r":
      letter="@";
      break;
      case "s":
      letter="`";
      break;
      case "t":
      letter="6";
      break;
      case "u":
      letter="2";
      break;
      case "v":
      letter="4";
      break;
      case "w":
      letter="|";
      break;
      case "x":
      letter="}";
      break;
      case "y":
      letter="{";
      break;
      case "z":
      letter="'";
      break;

      default:
      letter=messagearr[i];
      break;


    }

    encryptedMessageArr.push(letter);

  }
  encryptedMessage=encryptedMessageArr.join("");

}
